<?php
namespace App\Http\Controllers\sas\API;
use App\models\sas\sas_device;
use App\Http\Controllers\Controller;
use App\Sweet\SweetQueryBuilder;
use App\Sweet\SweetController;
use Illuminate\Http\Request;
use Bouncer;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class DeviceController extends SweetController
{

	public function add(Request $request)
    {
        if(!Bouncer::can('sas.device.insert'))
            throw new AccessDeniedHttpException();
    
		$InputName=$request->input('name');
		$InputDevicetype=$request->input('devicetype');
		$InputCode=$request->input('code');
		$InputNotete=$request->file('notete');
        if($InputNotete!=null){
            $InputNotete->move('img/',$InputNotete->getClientOriginalName());
            $InputNotete='img/'.$InputNotete->getClientOriginalName();
        }
        else
        { 
            $InputNotete='';
        }
		$InputOwnerunit=$request->input('ownerunit');
		$Device = sas_device::create(['name'=>$InputName,'devicetype_fid'=>$InputDevicetype,'code'=>$InputCode,'note_te'=>$InputNotete,'owner__unit_fid'=>$InputOwnerunit,'deletetime'=>-1]);
		return response()->json(['Data'=>$Device], 201);
	}
	public function update($id,Request $request)
    {
        if(!Bouncer::can('sas.device.edit'))
            throw new AccessDeniedHttpException();
    
        $InputName=$request->get('name');
        $InputDevicetype=$request->get('devicetype');
        $InputCode=$request->get('code');
        $InputNotete=$request->file('notete');
        if($InputNotete!=null){
            $InputNotete->move('img/',$InputNotete->getClientOriginalName());
            $InputNotete='img/'.$InputNotete->getClientOriginalName();
        }
        else
        { 
            $InputNotete='';
        }
        $InputOwnerunit=$request->get('ownerunit');
        $Device = new sas_device();
        $Device = $Device->find($id);
        $Device->name=$InputName;
        $Device->devicetype_fid=$InputDevicetype;
        $Device->code=$InputCode;
        if($InputNotete!=null)
            $Device->note_te=$InputNotete;
        $Device->owner__unit_fid=$InputOwnerunit;
        $Device->save();
        return response()->json(['Data'=>$Device], 202);
    }
    public function list(Request $request)
    {
        Bouncer::allow('admin')->to('sas.device.insert');
        Bouncer::allow('admin')->to('sas.device.edit');
        Bouncer::allow('admin')->to('sas.device.list');
        Bouncer::allow('admin')->to('sas.device.view');
        Bouncer::allow('admin')->to('sas.device.delete');
        //if(!Bouncer::can('sas.device.list'))
            //throw new AccessDeniedHttpException();
        $DeviceQuery = sas_device::where('id','>=','0');
        $DeviceQuery =SweetQueryBuilder::WhereLikeIfNotNull($DeviceQuery,'name',$request->get('name'));
        $DeviceQuery =SweetQueryBuilder::WhereLikeIfNotNull($DeviceQuery,'devicetype_fid',$request->get('devicetype'));
        $DeviceQuery =SweetQueryBuilder::WhereLikeIfNotNull($DeviceQuery,'code',$request->get('code'));
        $DeviceQuery =SweetQueryBuilder::WhereLikeIfNotNull($DeviceQuery,'owner__unit_fid',$request->get('ownerunit'));
        $Devices=$DeviceQuery->get();
        $DevicesArray=[];
        for($i=0;$i<count($Devices);$i++)
        {
            $DevicesArray[$i]=$Devices[$i]->toArray();
            $DevicetypeField=$Devices[$i]->devicetype();
            $DevicesArray[$i]['devicetypecontent']=$DevicetypeField==null?'':$DevicetypeField->name;
            $OwnerunitField=$Devices[$i]->ownerunit();
            $DevicesArray[$i]['ownerunitcontent']=$OwnerunitField==null?'':$OwnerunitField->name;
        }
        $Device = $this->getNormalizedList($DevicesArray);
        return response()->json(['Data'=>$Device,'RecordCount'=>count($Device)], 200);
    }
    public function get($id,Request $request)
    {
        //if(!Bouncer::can('sas.device.view'))
            //throw new AccessDeniedHttpException();
        $Device = $this->getNormalizedItem(sas_device::find($id)->toArray());
        return response()->json(['Data'=>$Device], 200);
    }
    public function delete($id,Request $request)
    {
        if(!Bouncer::can('sas.device.delete'))
            throw new AccessDeniedHttpException();
        $Device = sas_device::find($id);
        $Device->delete();
        return response()->json(['message'=>'deleted','Data'=>[]], 202);
    }
}