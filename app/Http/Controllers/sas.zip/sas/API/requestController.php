<?php
namespace App\Http\Controllers\sas\API;
use App\models\sas\sas_request;
use App\Http\Controllers\Controller;
use App\Sweet\SweetQueryBuilder;
use App\Sweet\SweetController;
use Illuminate\Http\Request;
use Bouncer;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class RequestController extends SweetController
{

	public function add(Request $request)
    {
        if(!Bouncer::can('sas.request.insert'))
            throw new AccessDeniedHttpException();
    
		$InputRequesttype=$request->input('requesttype');
		$InputDevice=$request->input('device');
		$InputDescriptionte=$request->file('descriptionte');
        if($InputDescriptionte!=null){
            $InputDescriptionte->move('img/',$InputDescriptionte->getClientOriginalName());
            $InputDescriptionte='img/'.$InputDescriptionte->getClientOriginalName();
        }
        else
        { 
            $InputDescriptionte='';
        }
		$InputPriority=$request->input('priority');
		$InputAttachmentflu=$request->file('attachmentflu');
        if($InputAttachmentflu!=null){
            $InputAttachmentflu->move('img/',$InputAttachmentflu->getClientOriginalName());
            $InputAttachmentflu='img/'.$InputAttachmentflu->getClientOriginalName();
        }
        else
        { 
            $InputAttachmentflu='';
        }
		$InputStatus=$request->input('status');
		$InputSenderunit=$request->input('senderunit');
		$InputCurrentunit=$request->input('currentunit');
		$InputAdminacceptancetime=$request->input('adminacceptancetime');
		$InputSecurityacceptancetime=$request->input('securityacceptancetime');
		$InputFullsendtime=$request->input('fullsendtime');
		$InputLetternumber=$request->input('letternumber');
		$InputLetterdate=$request->input('letterdate');
		$InputSenderuser=$request->input('senderuser');
		$Request = sas_request::create(['requesttype_fid'=>$InputRequesttype,'device_fid'=>$InputDevice,'description_te'=>$InputDescriptionte,'priority'=>$InputPriority,'attachment_flu'=>$InputAttachmentflu,'status_fid'=>$InputStatus,'sender__unit_fid'=>$InputSenderunit,'current__unit_fid'=>$InputCurrentunit,'adminacceptance_time'=>$InputAdminacceptancetime,'securityacceptance_time'=>$InputSecurityacceptancetime,'fullsend_time'=>$InputFullsendtime,'letternumber'=>$InputLetternumber,'letter_date'=>$InputLetterdate,'sender__user_fid'=>$InputSenderuser,'deletetime'=>-1]);
		return response()->json(['Data'=>$Request], 201);
	}
	public function update($id,Request $request)
    {
        if(!Bouncer::can('sas.request.edit'))
            throw new AccessDeniedHttpException();
    
        $InputRequesttype=$request->get('requesttype');
        $InputDevice=$request->get('device');
        $InputDescriptionte=$request->file('descriptionte');
        if($InputDescriptionte!=null){
            $InputDescriptionte->move('img/',$InputDescriptionte->getClientOriginalName());
            $InputDescriptionte='img/'.$InputDescriptionte->getClientOriginalName();
        }
        else
        { 
            $InputDescriptionte='';
        }
        $InputPriority=$request->get('priority');
        $InputAttachmentflu=$request->file('attachmentflu');
        if($InputAttachmentflu!=null){
            $InputAttachmentflu->move('img/',$InputAttachmentflu->getClientOriginalName());
            $InputAttachmentflu='img/'.$InputAttachmentflu->getClientOriginalName();
        }
        else
        { 
            $InputAttachmentflu='';
        }
        $InputStatus=$request->get('status');
        $InputSenderunit=$request->get('senderunit');
        $InputCurrentunit=$request->get('currentunit');
        $InputAdminacceptancetime=$request->get('adminacceptancetime');
        $InputSecurityacceptancetime=$request->get('securityacceptancetime');
        $InputFullsendtime=$request->get('fullsendtime');
        $InputLetternumber=$request->get('letternumber');
        $InputLetterdate=$request->get('letterdate');
        $InputSenderuser=$request->get('senderuser');
        $Request = new sas_request();
        $Request = $Request->find($id);
        $Request->requesttype_fid=$InputRequesttype;
        $Request->device_fid=$InputDevice;
        if($InputDescriptionte!=null)
            $Request->description_te=$InputDescriptionte;
        $Request->priority=$InputPriority;
        if($InputAttachmentflu!=null)
            $Request->attachment_flu=$InputAttachmentflu;
        $Request->status_fid=$InputStatus;
        $Request->sender__unit_fid=$InputSenderunit;
        $Request->current__unit_fid=$InputCurrentunit;
        $Request->adminacceptance_time=$InputAdminacceptancetime;
        $Request->securityacceptance_time=$InputSecurityacceptancetime;
        $Request->fullsend_time=$InputFullsendtime;
        $Request->letternumber=$InputLetternumber;
        $Request->letter_date=$InputLetterdate;
        $Request->sender__user_fid=$InputSenderuser;
        $Request->save();
        return response()->json(['Data'=>$Request], 202);
    }
    public function list(Request $request)
    {
        Bouncer::allow('admin')->to('sas.request.insert');
        Bouncer::allow('admin')->to('sas.request.edit');
        Bouncer::allow('admin')->to('sas.request.list');
        Bouncer::allow('admin')->to('sas.request.view');
        Bouncer::allow('admin')->to('sas.request.delete');
        //if(!Bouncer::can('sas.request.list'))
            //throw new AccessDeniedHttpException();
        $RequestQuery = sas_request::where('id','>=','0');
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'requesttype_fid',$request->get('requesttype'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'device_fid',$request->get('device'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'priority',$request->get('priority'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'status_fid',$request->get('status'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'sender__unit_fid',$request->get('senderunit'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'current__unit_fid',$request->get('currentunit'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'adminacceptance_time',$request->get('adminacceptancetime'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'securityacceptance_time',$request->get('securityacceptancetime'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'fullsend_time',$request->get('fullsendtime'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'letternumber',$request->get('letternumber'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'letter_date',$request->get('letterdate'));
        $RequestQuery =SweetQueryBuilder::WhereLikeIfNotNull($RequestQuery,'sender__user_fid',$request->get('senderuser'));
        $Requests=$RequestQuery->get();
        $RequestsArray=[];
        for($i=0;$i<count($Requests);$i++)
        {
            $RequestsArray[$i]=$Requests[$i]->toArray();
            $RequesttypeField=$Requests[$i]->requesttype();
            $RequestsArray[$i]['requesttypecontent']=$RequesttypeField==null?'':$RequesttypeField->name;
            $DeviceField=$Requests[$i]->device();
            $RequestsArray[$i]['devicecontent']=$DeviceField==null?'':$DeviceField->name;
            $StatusField=$Requests[$i]->status();
            $RequestsArray[$i]['statuscontent']=$StatusField==null?'':$StatusField->name;
            $SenderunitField=$Requests[$i]->senderunit();
            $RequestsArray[$i]['senderunitcontent']=$SenderunitField==null?'':$SenderunitField->name;
            $CurrentunitField=$Requests[$i]->currentunit();
            $RequestsArray[$i]['currentunitcontent']=$CurrentunitField==null?'':$CurrentunitField->name;
            $SenderuserField=$Requests[$i]->senderuser();
            $RequestsArray[$i]['senderusercontent']=$SenderuserField==null?'':$SenderuserField->name;
        }
        $Request = $this->getNormalizedList($RequestsArray);
        return response()->json(['Data'=>$Request,'RecordCount'=>count($Request)], 200);
    }
    public function get($id,Request $request)
    {
        //if(!Bouncer::can('sas.request.view'))
            //throw new AccessDeniedHttpException();
        $Request = $this->getNormalizedItem(sas_request::find($id)->toArray());
        return response()->json(['Data'=>$Request], 200);
    }
    public function delete($id,Request $request)
    {
        if(!Bouncer::can('sas.request.delete'))
            throw new AccessDeniedHttpException();
        $Request = sas_request::find($id);
        $Request->delete();
        return response()->json(['message'=>'deleted','Data'=>[]], 202);
    }
}